#include "StdAfx.h"
#include "Ce2Writer.h"

Ce2Writer::~Ce2Writer()
{
}
