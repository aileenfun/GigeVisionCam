#include "StdAfx.h"
#include "TrigImgPack.h"
std::map<UINT_PTR, TrigImgPack*> TrigImgPack::m_TrigImgPackMap;