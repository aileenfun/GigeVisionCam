#pragma once
class propFromFile
{
public:
	propFromFile(void);
	~propFromFile(void);
	int ReadFile();
	
};

