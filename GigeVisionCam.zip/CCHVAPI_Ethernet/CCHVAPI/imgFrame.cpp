#include "StdAfx.h"
#include "GigEimgFrame.h"
